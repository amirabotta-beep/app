.class public LMT/IosDialog2;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LMT/A;,
        LMT/B;
    }
.end annotation


# static fields
.field private static alert:Landroid/app/AlertDialog;

.field private static final short:[S


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const v0, 0x85

    new-array v0, v0, [S

    fill-array-data v0, :array_c

    sput-object v0, LMT/IosDialog2;->short:[S

    return-void

    nop

    :array_c
    .array-data 2
        0x5bes
        0x587s
        0x580s
        0x586s
        0x59ds
        0x59bs
        0x594s
        0x718s
        0x721s
        0x726s
        0x720s
        0x73bs
        0x73ds
        0x732s
        0x8f0s
        0x8c9s
        0x8ces
        0x8c8s
        0x8d3s
        0x8d5s
        0x8das
        0x55bs
        0x53es
        0x54as
        0x53es
        0x54es
        0x53es
        0x541s
        0x4e9s
        0x4e1s
        0x4e0s
        0x4aas
        0x4f0s
        0x4f0s
        0x4e2s
        0xa6as
        0xa79s
        0xa79s
        0xa79s
        0xa79s
        0xa79s
        0xa79s
        0x80bs
        0x818s
        0x818s
        0x818s
        0x818s
        0x818s
        0x818s
        0x61fs
        0x617s
        0x616s
        0x65cs
        0x606s
        0x606s
        0x614s
        0xbeas
        0xb8cs
        0xbf9s
        0xb8cs
        0xbf9s
        0xb8cs
        0xbf9s
        0x154s
        0x145s
        0x146s
        0x14es
        0x141s
        0x131s
        0x144s
        0xa80s
        0xae5s
        0xa91s
        0xae5s
        0xa95s
        0xae5s
        0xa9as
        0x602s
        0x667s
        0x615s
        0x615s
        0x612s
        0x612s
        0x617s
        0x1e3s
        0x186s
        0x186s
        0x186s
        0x186s
        0x186s
        0x186s
        0x58fs
        0x5eas
        0x5eas
        0x5eas
        0x5eas
        0x5eas
        0x5eas
        0x6e4s
        0x6ecs
        0x6eds
        0x6a7s
        0x6fds
        0x6fds
        0x6efs
        0xc35s
        0xc3ds
        0xc3cs
        0xc76s
        0xc2cs
        0xc2cs
        0xc3es
        0x901s
        0x909s
        0x908s
        0x942s
        0x918s
        0x918s
        0x90as
        0x600s
        0x608s
        0x609s
        0x643s
        0x619s
        0x619s
        0x60bs
        0x4a2s
        0x4b8s
        0x4e4s
        0x4b8s
        0x4e4s
        0x4b8s
        0x4e4s
    .end array-data
.end method

.method public constructor <init>()V
    .registers 55

    move-object/from16 v3, p0

    move-object v0, v3

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Mod(Landroid/content/Context;)V
    .registers 89
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    move-object/from16 v37, p0

    move-object/from16 v2, v37

    invoke-static {}, LMT/IosDialog2;->۟ۧۧۦۦ()Ljava/lang/String;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/ۣۧۧۤ;->ۣ۟ۧۤۧ(Ljava/lang/Object;)I

    move-result v29

    move/from16 v4, v29

    move-object/from16 v29, v2

    invoke-static/range {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۣۧۧۤ;->۟ۡۡ۠۟(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/content/SharedPreferences;

    move-result-object v29

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v50

    const v53, 0x5f5

    const v51, 0x0

    const v52, 0x7

    invoke-static/range {v50 .. v53}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v50

    move-object/from16 v30, v50

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/۟ۦۦ۠ۦ;->۠۟ۦۡ(Ljava/lang/Object;Ljava/lang/Object;I)I

    move-result v29

    move/from16 v30, v4

    move/from16 v0, v29

    move/from16 v1, v30

    if-eq v0, v1, :cond_6c9

    move-object/from16 v29, v2

    invoke-static/range {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۣۧۧۤ;->۟ۡۡ۠۟(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/content/SharedPreferences;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/۟ۦۦ۠ۦ;->ۣ۠ۤۥ(Ljava/lang/Object;)Landroid/content/SharedPreferences$Editor;

    move-result-object v29

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v43

    const v46, 0x753

    const v44, 0x7

    const v45, 0x7

    invoke-static/range {v43 .. v46}, LMT/۟۟ۥ۟۟;->۟ۡۥۤ([SIII)Ljava/lang/String;

    move-result-object v43

    move-object/from16 v30, v43

    move-object/from16 v31, v2

    invoke-static/range {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v32

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, LMT/ۣۧۧۤ;->۟ۡۡ۠۟(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/content/SharedPreferences;

    move-result-object v31

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v75

    const v78, 0x8bb

    const v76, 0xe

    const v77, 0x7

    invoke-static/range {v75 .. v78}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v75

    move-object/from16 v32, v75

    const/16 v33, 0x0

    invoke-static/range {v31 .. v33}, LMT/۟ۦۦ۠ۦ;->۠۟ۦۡ(Ljava/lang/Object;Ljava/lang/Object;I)I

    move-result v31

    const/16 v32, 0x1

    add-int/lit8 v31, v31, 0x1

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۨۤ۟ۢ(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/۟ۦۦ۠ۦ;->۟ۦۣۡ۟(Ljava/lang/Object;)Z

    move-result v29

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v5, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v6, v29

    move-object/from16 v29, v6

    const/16 v30, 0x28

    const/16 v31, 0x14

    const/16 v32, 0x28

    const/16 v33, 0x0

    invoke-static/range {v29 .. v33}, LMT/ۣۧۧۤ;->ۣ۟ۡۨۡ(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v5

    move-object/from16 v30, v6

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v5

    const/16 v30, 0x1

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v8, v29

    move-object/from16 v29, v7

    move-object/from16 v30, v8

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v7

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v72

    const v75, 0x578

    const v73, 0x15

    const v74, 0x7

    invoke-static/range {v72 .. v75}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v72

    move-object/from16 v30, v72

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/ۣۧۧۤ;->ۣ۟ۡۥۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v7

    const/16 v30, 0x1

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v10, v29

    move-object/from16 v29, v9

    move-object/from16 v30, v10

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v9

    const/16 v30, 0x0

    const/16 v31, 0x8

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-static/range {v29 .. v33}, LMT/۟ۦۦ۠ۦ;->ۤۧ۠۟(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v9

    const/16 v30, 0x11

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۢ۠ۤۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v9

    const/16 v30, 0x0

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    new-instance v29, Landroid/widget/TextView;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x2

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v12, v29

    move-object/from16 v29, v11

    move-object/from16 v30, v12

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۡۧ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v11

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/ۧۤۧۧ;->۟ۧۥۤۡ(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v11

    invoke-static {}, LMT/IosDialog2;->ۢۨۤۧ()Ljava/lang/String;

    move-result-object v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۧۤۡۨ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v11

    const/16 v30, 0x14

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->۟ۡۡ۟۠(Ljava/lang/Object;F)V

    move-object/from16 v29, v11

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v68

    const v71, 0x484

    const v69, 0x1c

    const v70, 0x7

    invoke-static/range {v68 .. v71}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v68

    move-object/from16 v31, v68

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x1

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v11

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v64

    const v67, 0xa49

    const v65, 0x23

    const v66, 0x7

    invoke-static/range {v64 .. v67}, LMT/۟ۦۦ۠ۦ;->۟۟ۥۨۦ([SIII)Ljava/lang/String;

    move-result-object v64

    move-object/from16 v30, v64

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۡۥۧ۟(Ljava/lang/Object;I)V

    move-object/from16 v29, v9

    move-object/from16 v30, v11

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v7

    move-object/from16 v30, v9

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v14, v29

    move-object/from16 v29, v13

    move-object/from16 v30, v14

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v13

    const/16 v30, 0x8

    const/16 v31, 0x0

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/۟ۦۦ۠ۦ;->ۤۧ۠۟(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v13

    const/16 v30, 0x11

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۢ۠ۤۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v13

    const/16 v30, 0x0

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    new-instance v29, Landroid/widget/TextView;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x2

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v16, v29

    move-object/from16 v29, v16

    const/16 v30, 0x11

    move/from16 v0, v30

    move-object/from16 v1, v29

    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    move-object/from16 v29, v15

    move-object/from16 v30, v16

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۡۧ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v15

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/ۧۤۧۧ;->۟ۧۥۤۡ(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v15

    const/16 v30, 0x11

    invoke-static/range {v29 .. v30}, LMT/ۣۧۧۤ;->ۥۡ۟۟(Ljava/lang/Object;I)V

    move-object/from16 v29, v15

    const/16 v30, 0x10

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->۟ۡۡ۟۠(Ljava/lang/Object;F)V

    move-object/from16 v29, v15

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v67

    const v70, 0x828

    const v68, 0x2a

    const v69, 0x7

    invoke-static/range {v67 .. v70}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v67

    move-object/from16 v30, v67

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۡۥۧ۟(Ljava/lang/Object;I)V

    move-object/from16 v29, v15

    invoke-static {}, LMT/IosDialog2;->۟۠ۨۥۣ()Ljava/lang/String;

    move-result-object v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۧۤۡۨ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v15

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v65

    const v68, 0x672

    const v66, 0x31

    const v67, 0x7

    invoke-static/range {v65 .. v68}, LMT/۟ۦۦ۠ۦ;->۟۟ۥۨۦ([SIII)Ljava/lang/String;

    move-result-object v65

    move-object/from16 v31, v65

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v13

    move-object/from16 v30, v15

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v7

    move-object/from16 v30, v13

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, 0x4

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v18, v29

    move-object/from16 v29, v17

    move-object/from16 v30, v18

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v17

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/۟ۦۦ۠ۦ;->ۤۧ۠۟(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v17

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v68

    const v71, 0xbc9

    const v69, 0x38

    const v70, 0x7

    invoke-static/range {v68 .. v71}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v68

    move-object/from16 v30, v68

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/ۣۧۧۤ;->ۣ۟ۡۥۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v17

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/۟ۦۦ۠ۦ;->ۤۧ۠۟(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v7

    move-object/from16 v30, v17

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v19, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, 0x32

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v20, v29

    move-object/from16 v29, v19

    move-object/from16 v30, v20

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v19

    const/16 v30, 0x11

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۢ۠ۤۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v19

    const/16 v30, 0x0

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    move-object/from16 v29, v19

    new-instance v30, LMT/A;

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    move-object/from16 v32, v2

    invoke-direct/range {v31 .. v32}, LMT/A;-><init>(Landroid/content/Context;)V

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->ۢ۟ۥۥ(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/widget/TextView;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v21, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x2

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v22, v29

    move-object/from16 v29, v21

    move-object/from16 v30, v22

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۡۧ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v21

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/ۧۤۧۧ;->۟ۧۥۤۡ(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v21

    invoke-static {}, LMT/IosDialog2;->ۣۨۨۥ()Ljava/lang/String;

    move-result-object v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۧۤۡۨ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v21

    const/16 v30, 0x10

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->۟ۡۡ۟۠(Ljava/lang/Object;F)V

    move-object/from16 v29, v21

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v70

    const v73, 0x177

    const v71, 0x3f

    const v72, 0x7

    invoke-static/range {v70 .. v73}, LMT/۟ۦۦ۠ۦ;->۟۟ۥۨۦ([SIII)Ljava/lang/String;

    move-result-object v70

    move-object/from16 v30, v70

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۡۥۧ۟(Ljava/lang/Object;I)V

    move-object/from16 v29, v19

    move-object/from16 v30, v21

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v7

    move-object/from16 v30, v19

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v5

    move-object/from16 v30, v7

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/widget/LinearLayout;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v23, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x1

    const/16 v32, 0x32

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v24, v29

    move-object/from16 v29, v24

    const/16 v30, 0xa

    move/from16 v0, v30

    move-object/from16 v1, v29

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    move-object/from16 v29, v23

    move-object/from16 v30, v24

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥ۟ۧۦ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v23

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v54

    const v57, 0xaa3

    const v55, 0x46

    const v56, 0x7

    invoke-static/range {v54 .. v57}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v54

    move-object/from16 v30, v54

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/ۣۧۧۤ;->ۣ۟ۡۥۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v23

    const/16 v30, 0x11

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۢ۠ۤۡ(Ljava/lang/Object;I)V

    move-object/from16 v29, v23

    const/16 v30, 0x0

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۥۧۨۢ(Ljava/lang/Object;I)V

    new-instance v29, Landroid/widget/TextView;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v25, v29

    new-instance v29, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    const/16 v31, -0x2

    const/16 v32, -0x2

    invoke-direct/range {v30 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v26, v29

    move-object/from16 v29, v25

    move-object/from16 v30, v26

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->۟ۡۧ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v25

    const/16 v30, 0x8

    const/16 v31, 0x8

    const/16 v32, 0x8

    const/16 v33, 0x8

    invoke-static/range {v29 .. v33}, LMT/ۧۤۧۧ;->۟ۧۥۤۡ(Ljava/lang/Object;IIII)V

    move-object/from16 v29, v25

    invoke-static {}, LMT/IosDialog2;->ۡۨۧ۟()Ljava/lang/String;

    move-result-object v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۧۤۡۨ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v25

    const/16 v30, 0x10

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->۟ۡۡ۟۠(Ljava/lang/Object;F)V

    move-object/from16 v29, v25

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v51

    const v54, 0x621

    const v52, 0x4d

    const v53, 0x7

    invoke-static/range {v51 .. v54}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v51

    move-object/from16 v30, v51

    invoke-static/range {v30 .. v30}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v30

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۡۥۧ۟(Ljava/lang/Object;I)V

    move-object/from16 v29, v23

    move-object/from16 v30, v25

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v5

    move-object/from16 v30, v23

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->۟ۥۦۡ۠(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v7

    const/16 v30, 0x28

    move/from16 v0, v30

    int-to-double v0, v0

    move-wide/from16 v30, v0

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-double v0, v0

    move-wide/from16 v32, v0

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v52

    const v55, 0x1c0

    const v53, 0x54

    const v54, 0x7

    invoke-static/range {v52 .. v55}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v52

    move-object/from16 v34, v52

    const/16 v35, 0x0

    invoke-static/range {v29 .. v35}, LMT/۟ۦۦ۠ۦ;->ۣ۟۟ۤ۠(Ljava/lang/Object;DDLjava/lang/Object;Z)V

    new-instance v29, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    invoke-direct/range {v30 .. v30}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v27, v29

    move-object/from16 v29, v27

    const v30, -0x30304

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->۠ۧۨۨ(Ljava/lang/Object;I)V

    move-object/from16 v29, v27

    const/16 v30, 0x0

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->۠ۤۥۥ(Ljava/lang/Object;II)V

    move-object/from16 v29, v27

    const/16 v30, 0x8

    move/from16 v0, v30

    new-array v0, v0, [F

    move-object/from16 v30, v0

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x0

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x1

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x2

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x3

    const/16 v33, 0x0

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x4

    const/16 v33, 0x28

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x5

    const/16 v33, 0x28

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x6

    const/16 v33, 0x28

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    const/16 v32, 0x7

    const/16 v33, 0x28

    move/from16 v0, v33

    int-to-float v0, v0

    move/from16 v33, v0

    aput v33, v31, v32

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۦۦۣۤ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v19

    move-object/from16 v30, v27

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->ۤۡۨۡ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v29, v19

    const/16 v30, 0x8

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۥۣۡۧ(Ljava/lang/Object;F)V

    move-object/from16 v29, v23

    const/16 v30, 0x19

    move/from16 v0, v30

    int-to-double v0, v0

    move-wide/from16 v30, v0

    const/16 v32, 0x0

    move/from16 v0, v32

    int-to-double v0, v0

    move-wide/from16 v32, v0

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v58

    const v61, 0x5ac

    const v59, 0x5b

    const v60, 0x7

    invoke-static/range {v58 .. v61}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v58

    move-object/from16 v34, v58

    const/16 v35, 0x1

    invoke-static/range {v29 .. v35}, LMT/۟ۦۦ۠ۦ;->ۣ۟۟ۤ۠(Ljava/lang/Object;DDLjava/lang/Object;Z)V

    move-object/from16 v29, v11

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v57

    const v60, 0x689

    const v58, 0x62

    const v59, 0x7

    invoke-static/range {v57 .. v60}, LMT/۟ۦۦ۠ۦ;->۟۟ۥۨۦ([SIII)Ljava/lang/String;

    move-result-object v57

    move-object/from16 v31, v57

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x1

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v15

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v51

    const v54, 0xc58

    const v52, 0x69

    const v53, 0x7

    invoke-static/range {v51 .. v54}, LMT/ۣۧۧۤ;->ۣ۟ۢۡۨ([SIII)Ljava/lang/String;

    move-result-object v51

    move-object/from16 v31, v51

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v21

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v46

    const v49, 0x96c

    const v47, 0x70

    const v48, 0x7

    invoke-static/range {v46 .. v49}, LMT/۟۟ۥ۟۟;->۟ۡۥۤ([SIII)Ljava/lang/String;

    move-result-object v46

    move-object/from16 v31, v46

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v25

    move-object/from16 v30, v2

    invoke-static/range {v30 .. v30}, LMT/۟۟ۥ۟۟;->ۧۦۤ(Ljava/lang/Object;)Landroid/content/res/AssetManager;

    move-result-object v30

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v55

    const v58, 0x66d

    const v56, 0x77

    const v57, 0x7

    invoke-static/range {v55 .. v58}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v55

    move-object/from16 v31, v55

    invoke-static/range {v30 .. v31}, LMT/ۧۤۧۧ;->۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;

    move-result-object v30

    const/16 v31, 0x0

    invoke-static/range {v29 .. v31}, LMT/ۧۤۧۧ;->ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v29, v23

    new-instance v30, LMT/B;

    move-object/from16 v36, v30

    move-object/from16 v30, v36

    move-object/from16 v31, v36

    invoke-direct/range {v31 .. v31}, LMT/B;-><init>()V

    invoke-static/range {v29 .. v30}, LMT/۟۟ۥ۟۟;->ۢ۟ۥۥ(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v29, Landroid/app/AlertDialog$Builder;

    move-object/from16 v36, v29

    move-object/from16 v29, v36

    move-object/from16 v30, v36

    move-object/from16 v31, v2

    invoke-direct/range {v30 .. v31}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    invoke-static/range {v29 .. v29}, LMT/ۧۤۧۧ;->۟ۡ۟ۥۣ(Ljava/lang/Object;)Landroid/app/AlertDialog;

    move-result-object v29

    sput-object v29, LMT/IosDialog2;->alert:Landroid/app/AlertDialog;

    invoke-static/range {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v29

    move-object/from16 v30, v5

    invoke-static/range {v29 .. v30}, LMT/ۧۤۧۧ;->ۥۦۤ۟(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static/range {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/۟ۦۦ۠ۦ;->۠ۦۦۧ(Ljava/lang/Object;)Landroid/view/Window;

    move-result-object v29

    const v30, 0x106000d

    invoke-static/range {v29 .. v30}, LMT/۟ۦۦ۠ۦ;->ۣۧۥ(Ljava/lang/Object;I)V

    invoke-static/range {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v29

    const/16 v30, 0x0

    invoke-static/range {v29 .. v30}, LMT/ۣۧۧۤ;->ۡۦۣۧ(Ljava/lang/Object;Z)V

    invoke-static/range {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/ۧۤۧۧ;->۟ۤۡ۟ۧ(Ljava/lang/Object;)V

    invoke-static/range {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v29

    invoke-static/range {v29 .. v29}, LMT/۟ۦۦ۠ۦ;->۠ۦۦۧ(Ljava/lang/Object;)Landroid/view/Window;

    move-result-object v29

    const/16 v30, 0x258

    const/16 v31, -0x2

    invoke-static/range {v29 .. v31}, LMT/۟۟ۥ۟۟;->۟۠ۧۤۥ(Ljava/lang/Object;II)V

    :cond_6c9
    return-void
.end method

.method public static _SetBackground(Landroid/view/View;DDLjava/lang/String;Z)V
    .registers 79
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "DD",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    move/from16 v27, p6

    move-object/from16 v26, p5

    move-wide/from16 v24, p3

    move-wide/from16 v22, p1

    move-object/from16 v21, p0

    move-object/from16 v1, v21

    move-wide/from16 v2, v22

    move-wide/from16 v4, v24

    move-object/from16 v6, v26

    move/from16 v7, v27

    move v13, v7

    if-eqz v13, :cond_a2

    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v9, v13

    move-object v13, v9

    move-object v14, v6

    invoke-static {v14}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v14

    invoke-static {v13, v14}, LMT/ۧۤۧۧ;->۠ۧۨۨ(Ljava/lang/Object;I)V

    move-object v13, v9

    move-wide v14, v2

    double-to-int v14, v14

    int-to-float v14, v14

    invoke-static {v13, v14}, LMT/ۧۤۧۧ;->۟ۡۢۥۦ(Ljava/lang/Object;F)V

    move-object v13, v1

    move-wide v14, v4

    double-to-int v14, v14

    int-to-float v14, v14

    invoke-static {v13, v14}, LMT/۟۟ۥ۟۟;->ۢ۠۠۠(Ljava/lang/Object;F)V

    new-instance v13, Landroid/content/res/ColorStateList;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    const/4 v15, 0x1

    new-array v15, v15, [[I

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    const/16 v17, 0x0

    const/16 v18, 0x0

    move/from16 v0, v18

    new-array v0, v0, [I

    move-object/from16 v18, v0

    aput-object v18, v16, v17

    const/16 v16, 0x1

    move/from16 v0, v16

    new-array v0, v0, [I

    move-object/from16 v16, v0

    move-object/from16 v20, v16

    move-object/from16 v16, v20

    move-object/from16 v17, v20

    const/16 v18, 0x0

    invoke-static/range {}, LMT/IosDialog2;->ۣۨۥ۠()[S

    move-result-object v56

    const v59, 0x481

    const v57, 0x7e

    const v58, 0x7

    invoke-static/range {v56 .. v59}, LMT/۟۟ۥ۟۟;->۟ۡۥۤ([SIII)Ljava/lang/String;

    move-result-object v56

    move-object/from16 v19, v56

    invoke-static/range {v19 .. v19}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v19

    aput v19, v17, v18

    invoke-direct/range {v14 .. v16}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    move-object v10, v13

    new-instance v13, Landroid/graphics/drawable/RippleDrawable;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    move-object v15, v10

    move-object/from16 v16, v9

    const/16 v17, 0x0

    check-cast v17, Landroid/graphics/drawable/Drawable;

    invoke-direct/range {v14 .. v17}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    move-object v11, v13

    move-object v13, v1

    const/4 v14, 0x1

    invoke-static {v13, v14}, LMT/۟ۦۦ۠ۦ;->ۣۨۨۨ(Ljava/lang/Object;Z)V

    move-object v13, v1

    move-object v14, v11

    invoke-static {v13, v14}, LMT/۟۟ۥ۟۟;->ۣ۟ۤۦۡ(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_a1
    return-void

    :cond_a2
    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v9, v13

    move-object v13, v9

    move-object v14, v6

    invoke-static {v14}, LMT/ۧۤۧۧ;->ۦۦۢۨ(Ljava/lang/Object;)I

    move-result v14

    invoke-static {v13, v14}, LMT/ۧۤۧۧ;->۠ۧۨۨ(Ljava/lang/Object;I)V

    move-object v13, v9

    move-wide v14, v2

    double-to-int v14, v14

    int-to-float v14, v14

    invoke-static {v13, v14}, LMT/ۧۤۧۧ;->۟ۡۢۥۦ(Ljava/lang/Object;F)V

    move-object v13, v1

    move-object v14, v9

    invoke-static {v13, v14}, LMT/۟۟ۥ۟۟;->ۣ۟ۤۦۡ(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v13, v1

    move-wide v14, v4

    double-to-int v14, v14

    int-to-float v14, v14

    invoke-static {v13, v14}, LMT/۟۟ۥ۟۟;->ۢ۠۠۠(Ljava/lang/Object;F)V

    goto :goto_a1
.end method

.method static synthetic access$L1000000()Landroid/app/AlertDialog;
    .registers 3

    invoke-static {}, LMT/IosDialog2;->ۣۡ۟ۧ()Landroid/app/AlertDialog;

    move-result-object v2

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$S1000000(Landroid/app/AlertDialog;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, LMT/IosDialog2;->alert:Landroid/app/AlertDialog;

    return-void
.end method

.method public static ۟۠ۨۥۣ()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-ltz v0, :cond_b

    invoke-static {}, LMT/D;->message()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method

.method public static ۟ۧۧۦۦ()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_b

    invoke-static {}, LMT/D;->showTime()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method

.method public static ۣۡ۟ۧ()Landroid/app/AlertDialog;
    .registers 1

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_9

    sget-object v0, LMT/IosDialog2;->alert:Landroid/app/AlertDialog;

    :goto_8
    return-object v0

    :cond_9
    const v0, 0x0

    goto :goto_8
.end method

.method public static ۡۨۧ۟()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_b

    invoke-static {}, LMT/D;->cancel_btn_text()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method

.method public static ۢۨۤۧ()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_b

    invoke-static {}, LMT/D;->title()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method

.method public static ۣۨۨۥ()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-ltz v0, :cond_b

    invoke-static {}, LMT/D;->okay_btn_text()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method

.method public static ۣۨۥ۠()[S
    .registers 1

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gtz v0, :cond_9

    sget-object v0, LMT/IosDialog2;->short:[S

    :goto_8
    return-object v0

    :cond_9
    const v0, 0x0

    goto :goto_8
.end method
