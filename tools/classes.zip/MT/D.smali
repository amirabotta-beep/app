.class public LMT/D;
.super Ljava/lang/Object;
.source "D.java"


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 22
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static cancel_btn_text()Ljava/lang/String;
    .registers 3

    .prologue
    .line 16
    const-string v2, "كنسل"

    move-object v0, v2

    return-object v0
.end method

.method public static message()Ljava/lang/String;
    .registers 3

    .prologue
    .line 9
    const-string v2, "تم تثبيت التطبيق من فولت تك ✅ استمتع بأفضل نسخة وتجربة مميزة."

    move-object v0, v2

    return-object v0
.end method

.method public static okay_btn_text()Ljava/lang/String;
    .registers 3

    .prologue
    .line 12
    const-string v2, "متجرنا"

    move-object v0, v2

    return-object v0
.end method

.method public static showTime()Ljava/lang/String;
    .registers 3

    .prologue
    .line 26
    const-string v2, "2"

    move-object v0, v2

    return-object v0
.end method

.method public static title()Ljava/lang/String;
    .registers 3

    .prologue
    .line 6
    const-string v2, "⚡ فولت تك"

    move-object v0, v2

    return-object v0
.end method

.method public static url()Ljava/lang/String;
    .registers 3

    .prologue
    .line 21
    const-string v2, "https://t.me/modder_guys"

    move-object v0, v2

    return-object v0
.end method
