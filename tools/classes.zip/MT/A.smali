.class LMT/A;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMT/IosDialog2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# static fields
.field private static final short:[S


# instance fields
.field private final val$context:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .registers 52

    const v0, 0x66

    new-array v0, v0, [S

    fill-array-data v0, :array_c

    sput-object v0, LMT/A;->short:[S

    return-void

    nop

    :array_c
    .array-data 2
        0x41ds
        0x412s
        0x418s
        0x40es
        0x413s
        0x415s
        0x418s
        0x452s
        0x415s
        0x412s
        0x408s
        0x419s
        0x412s
        0x408s
        0x452s
        0x41ds
        0x41fs
        0x408s
        0x415s
        0x413s
        0x412s
        0x452s
        0x42as
        0x435s
        0x439s
        0x42bs
        0x97fs
        0x958s
        0x940s
        0x957s
        0x95as
        0x95fs
        0x952s
        0x916s
        0x97as
        0x95fs
        0x958s
        0x95ds
        0x916s
        0x971s
        0x95fs
        0x940s
        0x953s
        0x958s
        0x916s
        0x974s
        0x94fs
        0x916s
        0x972s
        0x953s
        0x940s
        0x953s
        0x95as
        0x959s
        0x946s
        0x953s
        0x944s
        0x916s
        0x90ds
        0x91fs
        0x916s
        0x975s
        0x959s
        0x958s
        0x942s
        0x957s
        0x955s
        0x942s
        0x916s
        0x972s
        0x953s
        0x940s
        0x953s
        0x95as
        0x959s
        0x946s
        0x953s
        0x944s
        0x916s
        0x957s
        0x958s
        0x952s
        0x916s
        0x964s
        0x953s
        0x945s
        0x959s
        0x95as
        0x940s
        0x953s
        0x916s
        0x96fs
        0x959s
        0x943s
        0x944s
        0x916s
        0x97fs
        0x945s
        0x945s
        0x943s
        0x953s
        0x945s
    .end array-data
.end method

.method constructor <init>(Landroid/content/Context;)V
    .registers 58

    move-object/from16 v6, p1

    move-object/from16 v5, p0

    move-object v0, v5

    move-object v1, v6

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, LMT/A;->val$context:Landroid/content/Context;

    return-void
.end method

.method public static ۟ۢ۠ۨ(Ljava/lang/Object;)Landroid/content/Context;
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_b

    check-cast p0, LMT/A;

    iget-object v1, p0, LMT/A;->val$context:Landroid/content/Context;

    :goto_a
    return-object v1

    :cond_b
    const v1, 0x0

    goto :goto_a
.end method

.method public static ۟ۦۥ۠۠()[S
    .registers 1

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_9

    sget-object v0, LMT/A;->short:[S

    :goto_8
    return-object v0

    :cond_9
    const v0, 0x0

    goto :goto_8
.end method

.method public static ۥۦۡۥ()Ljava/lang/String;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_b

    invoke-static {}, LMT/D;->url()Ljava/lang/String;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 63
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    move-object/from16 v11, p1

    move-object/from16 v10, p0

    move-object v0, v10

    move-object v1, v11

    move-object v5, v0

    :try_start_7
    invoke-static {v5}, LMT/A;->۟ۢ۠ۨ(Ljava/lang/Object;)Landroid/content/Context;

    move-result-object v5

    new-instance v6, Landroid/content/Intent;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-static/range {}, LMT/A;->۟ۦۥ۠۠()[S

    move-result-object v43

    const v46, 0x47c

    const v44, 0x0

    const v45, 0x1a

    invoke-static/range {v43 .. v46}, LMT/ۧۤۧۧ;->۠ۨۦۣ([SIII)Ljava/lang/String;

    move-result-object v43

    move-object/from16 v8, v43

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {}, LMT/A;->ۥۦۡۥ()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, LMT/۟ۦۦ۠ۦ;->۟۟ۡ۟ۥ(Ljava/lang/Object;)Landroid/net/Uri;

    move-result-object v7

    invoke-static {v6, v7}, LMT/۟۟ۥ۟۟;->۟ۧۢ۟ۨ(Ljava/lang/Object;Ljava/lang/Object;)Landroid/content/Intent;

    move-result-object v6

    invoke-static {v5, v6}, LMT/۟۟ۥ۟۟;->ۦۤ۠ۡ(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_35
    .catch Landroid/content/ActivityNotFoundException; {:try_start_7 .. :try_end_35} :catch_3f

    :try_start_35
    invoke-static {}, LMT/IosDialog2;->m2()Landroid/app/AlertDialog;

    move-result-object v5

    if-eqz v5, :cond_3e

    invoke-virtual {v5}, Landroid/app/AlertDialog;->dismiss()V
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_3e} :catch_3e

    :catch_3e
    :cond_3e
    :goto_3e
    return-void

    :catch_3f
    move-exception v5

    move-object v3, v5

    move-object v5, v0

    invoke-static {v5}, LMT/A;->۟ۢ۠ۨ(Ljava/lang/Object;)Landroid/content/Context;

    move-result-object v5

    invoke-static/range {}, LMT/A;->۟ۦۥ۠۠()[S

    move-result-object v21

    const v24, 0x936

    const v22, 0x1a

    const v23, 0x4c

    invoke-static/range {v21 .. v24}, LMT/۟ۦۦ۠ۦ;->۟۟ۥۨۦ([SIII)Ljava/lang/String;

    move-result-object v21

    move-object/from16 v6, v21

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, LMT/ۧۤۧۧ;->۟ۤۥۦۣ(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-static {v5}, LMT/ۣۧۧۤ;->۟ۡۨۨ۠(Ljava/lang/Object;)V

    :try_start_61
    invoke-static {}, LMT/IosDialog2;->m2()Landroid/app/AlertDialog;

    move-result-object v5

    if-eqz v5, :cond_6a

    invoke-virtual {v5}, Landroid/app/AlertDialog;->dismiss()V
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_61 .. :try_end_6a} :catch_6a

    :catch_6a
    :cond_6a
    goto :goto_3e
.end method
