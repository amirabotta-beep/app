.class LMT/B;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LMT/IosDialog2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# direct methods
.method static constructor <clinit>()V
    .registers 52

    return-void
.end method

.method constructor <init>()V
    .registers 55

    move-object/from16 v3, p0

    move-object v0, v3

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ۦۢ۟۟()Landroid/app/AlertDialog;
    .registers 2

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-lez v0, :cond_b

    invoke-static {}, LMT/IosDialog2;->access$L1000000()Landroid/app/AlertDialog;

    move-result-object v0

    :goto_a
    return-object v0

    :cond_b
    const v0, 0x0

    goto :goto_a
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 57
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    move-object/from16 v5, p1

    move-object/from16 v4, p0

    move-object v0, v4

    move-object v1, v5

    invoke-static {}, LMT/B;->ۦۢ۟۟()Landroid/app/AlertDialog;

    move-result-object v3

    invoke-static {v3}, LMT/ۣۧۧۤ;->ۥۦۤۥ(Ljava/lang/Object;)V

    return-void
.end method
