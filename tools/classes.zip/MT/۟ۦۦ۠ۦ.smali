.class public LMT/۟ۦۦ۠ۦ;
.super Ljava/lang/Object;


# static fields
.field public static ۦۥۡۧ:I = -0x62


# direct methods
.method static constructor <clinit>()V
    .registers 52

    return-void
.end method

.method public static ۟۟ۡ۟ۥ(Ljava/lang/Object;)Landroid/net/Uri;
    .registers 2

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-ltz v0, :cond_d

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    :goto_c
    return-object v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۣ۟۟ۤ۠(Ljava/lang/Object;DDLjava/lang/Object;Z)V
    .registers 8

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_e

    check-cast p0, Landroid/view/View;

    check-cast p5, Ljava/lang/String;

    invoke-static/range {p0 .. p6}, LMT/IosDialog2;->_SetBackground(Landroid/view/View;DDLjava/lang/String;Z)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۟۟ۥۨۦ([SIII)Ljava/lang/String;
    .registers 58

    move/from16 v6, p3

    move/from16 v5, p2

    move/from16 v4, p1

    move-object/from16 v3, p0

    new-array v1, v5, [C

    const/4 v0, 0x0

    :goto_b
    if-ge v0, v5, :cond_18

    add-int v2, v4, v0

    aget-short v2, v3, v2

    xor-int/2addr v2, v6

    int-to-char v2, v2

    aput-char v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_18
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public static ۟ۡۧ(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_e

    check-cast p0, Landroid/widget/TextView;

    check-cast p1, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۣ۟ۧۦ۟(Ljava/lang/String;)Ljava/lang/String;
    .registers 60

    move-object/from16 v8, p0

    const/4 v0, 0x0

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v2

    move v1, v0

    :goto_c
    const/16 v4, 0xf

    if-lt v1, v4, :cond_32

    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    invoke-direct {v1, v4}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    :goto_1b
    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v4

    if-gtz v4, :cond_65

    invoke-static {v1}, LMT/۟۟ۥ۟۟;->ۦۥ۟ۦ(Ljava/lang/Object;)[B

    move-result-object v1

    array-length v3, v1

    invoke-static {v2}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v4

    :goto_2a
    if-lt v0, v3, :cond_7e

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    return-object v0

    :cond_32
    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v3}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v1}, LMT/۟۟ۥ۟۟;->ۣۧۢۧ(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v3}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v2}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۦۣۨۨ()D

    move-result-wide v4

    const/16 v6, 0xa

    int-to-double v6, v6

    mul-double/2addr v4, v6

    double-to-int v4, v4

    xor-int/2addr v4, v1

    invoke-static {v2, v4}, LMT/۟۟ۥ۟۟;->۟ۦۣ۟ۦ(Ljava/lang/Object;I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {v2}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    goto :goto_c

    :cond_65
    const/4 v4, -0x2

    invoke-static {v8, v4}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v4

    invoke-static {v3, v4}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v4

    shl-int/lit8 v4, v4, 0x4

    const/4 v5, -0x1

    invoke-static {v8, v5}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v5

    invoke-static {v3, v5}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v5

    or-int/2addr v4, v5

    invoke-static {v1, v4}, LMT/۟۟ۥ۟۟;->ۦۨۨۨ(Ljava/lang/Object;I)V

    goto :goto_1b

    :cond_7e
    aget-byte v5, v1, v0

    rem-int v6, v0, v4

    invoke-static {v2, v6}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v6

    xor-int/2addr v5, v6

    int-to-byte v5, v5

    aput-byte v5, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2a
.end method

.method public static ۟ۥۧۨۢ(Ljava/lang/Object;I)V
    .registers 3

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gtz v0, :cond_c

    check-cast p0, Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۟ۦۣۡ۟(Ljava/lang/Object;)Z
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_d

    check-cast p0, Landroid/content/SharedPreferences$Editor;

    invoke-interface/range {p0 .. p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v0

    :goto_c
    return v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۠۟ۦۡ(Ljava/lang/Object;Ljava/lang/Object;I)I
    .registers 4

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_f

    check-cast p0, Landroid/content/SharedPreferences;

    check-cast p1, Ljava/lang/String;

    invoke-interface/range {p0 .. p2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    :goto_e
    return v0

    :cond_f
    const v0, 0x0

    goto :goto_e
.end method

.method public static ۠ۦۦۧ(Ljava/lang/Object;)Landroid/view/Window;
    .registers 2

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-ltz v0, :cond_d

    check-cast p0, Landroid/app/AlertDialog;

    invoke-virtual/range {p0 .. p0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    :goto_c
    return-object v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۡۥۧ۟(Ljava/lang/Object;I)V
    .registers 3

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gtz v0, :cond_c

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۣ۠ۤۥ(Ljava/lang/Object;)Landroid/content/SharedPreferences$Editor;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-ltz v0, :cond_d

    check-cast p0, Landroid/content/SharedPreferences;

    invoke-interface/range {p0 .. p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    :goto_c
    return-object v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۤۧ۠۟(Ljava/lang/Object;IIII)V
    .registers 6

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_c

    check-cast p0, Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۥۣۨۡ()I
    .registers 2

    const v0, -0x1aa7f7

    const-string v1, "۟ۧ۟"

    invoke-static {v1}, LMT/ۧۤۧۧ;->۟ۢ۟ۦۡ(Ljava/lang/Object;)I

    move-result v1

    xor-int v0, v0, v1

    return v0
.end method

.method public static ۦۦۣۤ(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_e

    check-cast p0, Landroid/graphics/drawable/GradientDrawable;

    check-cast p1, [F

    invoke-virtual/range {p0 .. p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۣۧۥ(Ljava/lang/Object;I)V
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_c

    check-cast p0, Landroid/view/Window;

    invoke-virtual/range {p0 .. p1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۧۤۡۨ(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-ltz v0, :cond_e

    check-cast p0, Landroid/widget/TextView;

    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۣۨۨۨ(Ljava/lang/Object;Z)V
    .registers 3

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_c

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0, p1}, Landroid/view/View;->setClickable(Z)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method
