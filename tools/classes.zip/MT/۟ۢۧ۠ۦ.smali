.class public LMT/۟ۢۧ۠ۦ;
.super Ljava/lang/Object;


# static fields
.field public static ۟ۤۤۡ:Z = true


# direct methods
.method static constructor <clinit>()V
    .registers 52

    return-void
.end method

.method public static ۟ۦۡۥۢ([SIII)Ljava/lang/String;
    .registers 58

    move/from16 v6, p3

    move/from16 v5, p2

    move/from16 v4, p1

    move-object/from16 v3, p0

    new-array v1, v5, [C

    const/4 v0, 0x0

    :goto_b
    if-ge v0, v5, :cond_18

    add-int v2, v4, v0

    aget-short v2, v3, v2

    xor-int/2addr v2, v6

    int-to-char v2, v2

    aput-char v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_18
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public static ۠ۤۨ(Ljava/lang/String;)Ljava/lang/String;
    .registers 60

    move-object/from16 v8, p0

    const/4 v1, 0x0

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v2

    move v0, v1

    :goto_c
    const/16 v4, 0xf

    if-lt v0, v4, :cond_37

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    invoke-direct {v4, v0}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    move v0, v1

    :goto_1c
    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v5

    if-lt v0, v5, :cond_6a

    invoke-static {v4}, LMT/۟۟ۥ۟۟;->ۦۥ۟ۦ(Ljava/lang/Object;)[B

    move-result-object v3

    array-length v4, v3

    invoke-static {v2}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v5

    move v0, v1

    :goto_2c
    if-lt v0, v4, :cond_85

    :goto_2e
    array-length v0, v3

    if-lt v1, v0, :cond_94

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v3}, Ljava/lang/String;-><init>([B)V

    return-object v0

    :cond_37
    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v3}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v0}, LMT/۟۟ۥ۟۟;->ۣۧۢۧ(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v3}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v2}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۦۣۨۨ()D

    move-result-wide v4

    const/16 v6, 0xa

    int-to-double v6, v6

    mul-double/2addr v4, v6

    double-to-int v4, v4

    xor-int/2addr v4, v0

    invoke-static {v2, v4}, LMT/۟۟ۥ۟۟;->۟ۦۣ۟ۦ(Ljava/lang/Object;I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {v2}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_6a
    invoke-static {v8, v0}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v5

    invoke-static {v3, v5}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v5

    shl-int/lit8 v5, v5, 0x4

    add-int/lit8 v6, v0, 0x1

    invoke-static {v8, v6}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v6

    invoke-static {v3, v6}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v6

    or-int/2addr v5, v6

    invoke-static {v4, v5}, LMT/۟۟ۥ۟۟;->ۦۨۨۨ(Ljava/lang/Object;I)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_1c

    :cond_85
    aget-byte v6, v3, v0

    rem-int v7, v0, v5

    invoke-static {v2, v7}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v7

    xor-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, v3, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_2c

    :cond_94
    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v0

    add-int/lit8 v1, v0, 0x1

    goto :goto_2e
.end method

.method public static ۥۤۡۨ()I
    .registers 2

    const v0, 0x6df

    const-string v1, "ۦ"

    invoke-static {v1}, LMT/ۧۤۧۧ;->۟ۢ۟ۦۡ(Ljava/lang/Object;)I

    move-result v1

    xor-int v0, v0, v1

    return v0
.end method
