.class public LMT/ۧۤۧۧ;
.super Ljava/lang/Object;


# static fields
.field public static ۣ۟ۧۥۦ:Z = true


# direct methods
.method static constructor <clinit>()V
    .registers 52

    return-void
.end method

.method public static ۟۟۟ۤ۟(Ljava/lang/Object;Ljava/lang/Object;)Landroid/graphics/Typeface;
    .registers 3

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-ltz v0, :cond_f

    check-cast p0, Landroid/content/res/AssetManager;

    check-cast p1, Ljava/lang/String;

    invoke-static/range {p0 .. p1}, Landroid/graphics/Typeface;->createFromAsset(Landroid/content/res/AssetManager;Ljava/lang/String;)Landroid/graphics/Typeface;

    move-result-object v0

    :goto_e
    return-object v0

    :cond_f
    const v0, 0x0

    goto :goto_e
.end method

.method public static ۟۟ۤ۠ۡ(Ljava/lang/Object;I)C
    .registers 3

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_d

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    :goto_c
    return v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۟ۡ۟ۥۣ(Ljava/lang/Object;)Landroid/app/AlertDialog;
    .registers 2

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-ltz v0, :cond_d

    check-cast p0, Landroid/app/AlertDialog$Builder;

    invoke-virtual/range {p0 .. p0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    :goto_c
    return-object v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۟ۡۡ۟۠(Ljava/lang/Object;F)V
    .registers 3

    invoke-static {}, LMT/۟ۢۧ۠ۦ;->ۥۤۡۨ()I

    move-result v0

    if-lez v0, :cond_c

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/TextView;->setTextSize(F)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۟ۡۢۥۦ(Ljava/lang/Object;F)V
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_c

    check-cast p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۟ۢ۟ۦۡ(Ljava/lang/Object;)I
    .registers 52

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    return v0
.end method

.method public static ۟ۢ۟ۦۡ(Ljava/lang/String;)Ljava/lang/Class;
    .registers 56
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/Class",
            "<*>;^",
            "Ljava/lang/ClassNotFoundException;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    move-object/from16 v4, p0

    move-object v0, v4

    move-object v3, v0

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    move-object v0, v3

    return-object v0
.end method

.method public static ۟ۢ۟ۦۡ([SIII)Ljava/lang/String;
    .registers 58

    move/from16 v6, p3

    move/from16 v5, p2

    move/from16 v4, p1

    move-object/from16 v3, p0

    new-array v1, v5, [C

    const/4 v0, 0x0

    :goto_b
    if-ge v0, v5, :cond_18

    add-int v2, v4, v0

    aget-short v2, v3, v2

    xor-int/2addr v2, v6

    int-to-char v2, v2

    aput-char v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_18
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public static ۟ۤۡ۟ۧ(Ljava/lang/Object;)V
    .registers 2

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_c

    check-cast p0, Landroid/app/AlertDialog;

    invoke-virtual/range {p0 .. p0}, Landroid/app/AlertDialog;->show()V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۟ۤۥۦۣ(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/widget/Toast;
    .registers 4

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_f

    check-cast p0, Landroid/content/Context;

    check-cast p1, Ljava/lang/CharSequence;

    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    :goto_e
    return-object v0

    :cond_f
    const v0, 0x0

    goto :goto_e
.end method

.method public static ۣ۟ۧۡ(Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 4

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_e

    check-cast p0, Landroid/widget/TextView;

    check-cast p1, Landroid/graphics/Typeface;

    invoke-virtual/range {p0 .. p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۟ۧۥۡۧ(Ljava/lang/Object;I)I
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_d

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    :goto_c
    return v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۟ۧۥۤۡ(Ljava/lang/Object;IIII)V
    .registers 6

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gtz v0, :cond_c

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual/range {p0 .. p4}, Landroid/widget/TextView;->setPadding(IIII)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۠ۤۥۥ(Ljava/lang/Object;II)V
    .registers 4

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_c

    check-cast p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual/range {p0 .. p2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۠ۧۨۨ(Ljava/lang/Object;I)V
    .registers 3

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-lez v0, :cond_c

    check-cast p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-virtual/range {p0 .. p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۠ۨۦۣ([SIII)Ljava/lang/String;
    .registers 58

    move/from16 v6, p3

    move/from16 v5, p2

    move/from16 v4, p1

    move-object/from16 v3, p0

    new-array v1, v5, [C

    const/4 v0, 0x0

    :goto_b
    if-ge v0, v5, :cond_18

    add-int v2, v4, v0

    aget-short v2, v3, v2

    xor-int/2addr v2, v6

    int-to-char v2, v2

    aput-char v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_18
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([C)V

    return-object v0
.end method

.method public static ۡۥۨ۠(Ljava/lang/String;)Ljava/lang/String;
    .registers 60

    move-object/from16 v8, p0

    const/4 v1, 0x0

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v2

    move v0, v1

    :goto_c
    const/16 v4, 0xf

    if-lt v0, v4, :cond_36

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    invoke-direct {v4, v0}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    move v0, v1

    :goto_1c
    invoke-static {v8}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v5

    if-lt v0, v5, :cond_69

    invoke-static {v4}, LMT/۟۟ۥ۟۟;->ۦۥ۟ۦ(Ljava/lang/Object;)[B

    move-result-object v0

    array-length v3, v0

    invoke-static {v2}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v4

    :goto_2b
    if-gtz v3, :cond_84

    :goto_2d
    array-length v2, v0

    if-lt v1, v2, :cond_92

    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, v0}, Ljava/lang/String;-><init>([B)V

    return-object v1

    :cond_36
    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v3}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v0}, LMT/۟۟ۥ۟۟;->ۣۧۢۧ(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-static {v3}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuffer;

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    invoke-static {v4, v2}, LMT/ۧۤۧۧ;->ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {}, LMT/۟۟ۥ۟۟;->ۦۣۨۨ()D

    move-result-wide v4

    const/16 v6, 0xa

    int-to-double v6, v6

    mul-double/2addr v4, v6

    double-to-int v4, v4

    xor-int/2addr v4, v0

    invoke-static {v2, v4}, LMT/۟۟ۥ۟۟;->۟ۦۣ۟ۦ(Ljava/lang/Object;I)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-static {v2}, LMT/ۣۧۧۤ;->ۤۥۣۢ(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_69
    invoke-static {v8, v0}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v5

    invoke-static {v3, v5}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v5

    shl-int/lit8 v5, v5, 0x4

    add-int/lit8 v6, v0, 0x1

    invoke-static {v8, v6}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v6

    invoke-static {v3, v6}, LMT/ۧۤۧۧ;->۟ۧۥۡۧ(Ljava/lang/Object;I)I

    move-result v6

    or-int/2addr v5, v6

    invoke-static {v4, v5}, LMT/۟۟ۥ۟۟;->ۦۨۨۨ(Ljava/lang/Object;I)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_1c

    :cond_84
    const/4 v5, -0x1

    aget-byte v6, v0, v5

    rem-int v7, v5, v4

    invoke-static {v2, v7}, LMT/ۧۤۧۧ;->۟۟ۤ۠ۡ(Ljava/lang/Object;I)C

    move-result v7

    xor-int/2addr v6, v7

    int-to-byte v6, v6

    aput-byte v6, v0, v5

    goto :goto_2b

    :cond_92
    invoke-static {}, LMT/۟۟ۥ۟۟;->ۨۧۡۥ()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, LMT/ۣۧۧۤ;->۟ۦۣ۠ۦ(Ljava/lang/Object;)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_2d
.end method

.method public static ۢ۠ۤۡ(Ljava/lang/Object;I)V
    .registers 3

    invoke-static {}, LMT/ۣۧۧۤ;->۟ۦۦ۟ۨ()I

    move-result v0

    if-lez v0, :cond_c

    check-cast p0, Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/LinearLayout;->setGravity(I)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۣۣۡۧ()I
    .registers 2

    const v0, -0x1ab35e

    const-string v1, "ۢۧۦ"

    invoke-static {v1}, LMT/ۧۤۧۧ;->۟ۢ۟ۦۡ(Ljava/lang/Object;)I

    move-result v1

    xor-int v0, v0, v1

    return v0
.end method

.method public static ۥۣۡۧ(Ljava/lang/Object;F)V
    .registers 3

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gtz v0, :cond_c

    check-cast p0, Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p1}, Landroid/widget/LinearLayout;->setElevation(F)V

    :goto_b
    return-void

    :cond_c
    goto :goto_b
.end method

.method public static ۥۦۤ۟(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gez v0, :cond_e

    check-cast p0, Landroid/app/AlertDialog;

    check-cast p1, Landroid/view/View;

    invoke-virtual/range {p0 .. p1}, Landroid/app/AlertDialog;->setView(Landroid/view/View;)V

    :goto_d
    return-void

    :cond_e
    goto :goto_d
.end method

.method public static ۦۦۢۨ(Ljava/lang/Object;)I
    .registers 2

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_d

    check-cast p0, Ljava/lang/String;

    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    :goto_c
    return v0

    :cond_d
    const v0, 0x0

    goto :goto_c
.end method

.method public static ۧۡۡۥ(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/StringBuffer;
    .registers 3

    invoke-static {}, LMT/۟ۦۦ۠ۦ;->ۥۣۨۡ()I

    move-result v0

    if-gez v0, :cond_f

    check-cast p0, Ljava/lang/StringBuffer;

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    :goto_e
    return-object v0

    :cond_f
    const v0, 0x0

    goto :goto_e
.end method

.method public static ۨۤ۟ۢ(Ljava/lang/Object;Ljava/lang/Object;I)Landroid/content/SharedPreferences$Editor;
    .registers 4

    invoke-static {}, LMT/ۧۤۧۧ;->ۣۣۡۧ()I

    move-result v0

    if-gtz v0, :cond_f

    check-cast p0, Landroid/content/SharedPreferences$Editor;

    check-cast p1, Ljava/lang/String;

    invoke-interface/range {p0 .. p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    :goto_e
    return-object v0

    :cond_f
    const v0, 0x0

    goto :goto_e
.end method
